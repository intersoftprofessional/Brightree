<?php
$link = mysql_connect('localhost', 'skj_brightree', '@dmin123') or die(''.mysql_error());
$database="skj_brightree_patient_app";
mysql_select_db($database);
?>