<?php
require_once("class/class.commonwebservice.php");
require_once('class/USPSAddressVerify.php');
//require_once('class/connection.php');


//Initiate and set the username password provided from brighttree
$obj = new CommonWebService("https://webservices.brightree.net/v0100-1501/ReferenceDataService/ReferenceDataService.svc","shaeva@chspharmapitest","coffee4u");


$result = $obj->TaxZoneFetchAll();

$xml = simplexml_load_string((string) $result);

$records =$xml->children('s',true)->children()->TaxZoneFetchAllResponse->children()->TaxZoneFetchAllResult->children('a',true)->Items->children('b',true);

$return=array();
$count=1;

if($records && ( count($records) > 0)) {
	
	foreach($records->TaxZone as $key => $taxzone)
	{
		$return[$count]['taxzone_ID'] = (string) $taxzone->children()->ID;
		$return[$count]['taxzone_name'] = (string) $taxzone->children()->Value;
		$count++;
	}
	echo '<pre>'.print_r($return,true).'</pre>';
		
}else {
	echo 'No TaxZone Found';
}