<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
/**
 * CodeIgniter
 *
 * An open source application development framework for PHP 5.1.6 or newer
 *
 * @package		CodeIgniter
 * @author		ExpressionEngine Dev Team
 * @copyright	Copyright (c) 2008 - 2011, EllisLab, Inc.
 * @license		http://codeigniter.com/user_guide/license.html
 * @link		http://codeigniter.com
 * @since		Version 1.0
 * @filesource
 */
// ------------------------------------------------------------------------

/**
 * Address_Verify Class
 *
 * @package		CodeIgniter
 * @subpackage	Libraries
 */
class Isp_Address_Verify {

    var $obj;

    /**
     * Constructor
     *
     * @access	public
     * @param	array	initialization parameters
     */
    public function __construct($params = array()) {
        require_once("class/class.brighttreepatientservice.php");
        require_once('class/USPSAddressVerify.php');
        
        //Initiate and set the username password provided from brighttree
        $this->obj = new BrighttreePatientService("https://webservices.brightree.net/v0100-1302/OrderEntryService/PatientService.svc", "apiuser@GenevaWoodsSBX", "gw2015!!");
    }

    // --------------------------------------------------------------------

    /**
     * Initialize Preferences
     *
     * @access	public
     * @param	array	initialization parameters
     * @return	void
     */
    public function verify($params = array()) {
        
        //$result = $this->obj->PatientSearch('2015-05-19T05:25:16', '2015-05-19T05:25:17');
        $result = $this->obj->PatientSearch($params['start_date'], $params['end_date']);

        $xml = simplexml_load_string((string) $result);
        $totalRecords = $xml->children('s', true)->children()->PatientSearchResponse->children()->PatientSearchResult->children('a', true)->TotalItemCount;
        $records = $xml->children('s', true)->children()->PatientSearchResponse->children()->PatientSearchResult->children('a', true)->Items->children('b', true)->PatientSearchResponse;
        
        
		$returnresponse['total_patients'] = 0;
		$returnresponse['patients_updated'] = 0;
		$returnresponse['patients_not_updated'] = 0;
        
		//traverse to all records
        if($records && (count($records) > 0)) {            
            $returnresponse['total_patients'] = count($records);
            foreach ($records as $key => $record) {
                //get brightreeID
                $BrightreeID = (string) $record->children('b', true)->BrightreeID;

                //Get object of patient from brightree 
                $patient = $this->obj->PatientFetchByBrightreeID($BrightreeID);

                $xml = simplexml_load_string((string) $patient);

                $patient = $xml->children('s', true)->children()->PatientFetchByBrightreeIDResponse->children()->PatientFetchByBrightreeIDResult
                                ->children('a', true)->Items->children('b', true)->Patient;



                //get delivery address of patient
                $AddressLine1 = (string) $patient->children('b', true)->PatientGeneralInfo->children('b', true)->DeliveryAddress->children('c', true)->AddressLine1;
                $AddressLine2 = (string) $patient->children('b', true)->PatientGeneralInfo->children('b', true)->DeliveryAddress->children('c', true)->AddressLine2;
                $AddressLine3 = (string) $patient->children('b', true)->PatientGeneralInfo->children('b', true)->DeliveryAddress->children('c', true)->AddressLine3;
                $City = (string) $patient->children('b', true)->PatientGeneralInfo->children('b', true)->DeliveryAddress->children('c', true)->City;
                $Country = (string) $patient->children('b', true)->PatientGeneralInfo->children('b', true)->DeliveryAddress->children('c', true)->Country;
                $County = (string) $patient->children('b', true)->PatientGeneralInfo->children('b', true)->DeliveryAddress->children('c', true)->County;
                $PostalCode = (string) $patient->children('b', true)->PatientGeneralInfo->children('b', true)->DeliveryAddress->children('c', true)->PostalCode;
                $State = (string) $patient->children('b', true)->PatientGeneralInfo->children('b', true)->DeliveryAddress->children('c', true)->State;


                //Initiate and set the username provided from usps
                $verify = new USPSAddressVerify('272REACH6842');

                // Create new address object and assign the properties
                // apartently the order you assign them is important so make sure
                // to set them as the example below
                $address = new USPSAddress;
                $address->setFirmName('');
                $address->setApt(trim($AddressLine2));
                $address->setAddress(trim($AddressLine1));
                $address->setCity(trim($City));
                $address->setState(trim($State));
                $address->setZip5(trim($PostalCode));
                $address->setZip4('');

                // Add the address object to the address verify class
                $verify->addAddress($address);

                // Perform the request and return result
                $verify->verify();

                $correctAddress = $verify->getArrayResponse();
				
				//save name of patient				
				$patient_name_obj = $patient->children('b', true)->PatientGeneralInfo->children('b', true)->Name->children('c', true);
				$returnresponse['patients'][$BrightreeID]['first_name']= (string) $patient_name_obj->First;
				$returnresponse['patients'][$BrightreeID]['last_name']= (string) $patient_name_obj->Last;
				
				//save old address in response
				$old_delivery_address_obj = $patient->children('b', true)->PatientGeneralInfo->children('b', true)->DeliveryAddress->children('c', true);
				$returnresponse['patients'][$BrightreeID]['old_addr']['AddressLine1'] = (string) $old_delivery_address_obj->AddressLine1;
				$returnresponse['patients'][$BrightreeID]['old_addr']['AddressLine2'] = (string) $old_delivery_address_obj->AddressLine2;
				$returnresponse['patients'][$BrightreeID]['old_addr']['City'] = (string) $old_delivery_address_obj->City;
				$returnresponse['patients'][$BrightreeID]['old_addr']['PostalCode'] = (string) $old_delivery_address_obj->PostalCode;
				$returnresponse['patients'][$BrightreeID]['old_addr']['State'] = (string) $old_delivery_address_obj->State;

                if ($verify->isSuccess()) {
					$returnresponse['patients'][$BrightreeID]['address_verify'] = true;                    
					
                    //Now Update the correct deliveryAddress in the patient object
                    $patient->children('b', true)->PatientGeneralInfo->children('b', true)->DeliveryAddress->children('c', true)->AddressLine1 = (isset($correctAddress['AddressValidateResponse']['Address']['Address2'])) ? trim($correctAddress['AddressValidateResponse']['Address']['Address2']) : '';
                    $patient->children('b', true)->PatientGeneralInfo->children('b', true)->DeliveryAddress->children('c', true)->AddressLine2 = (isset($correctAddress['AddressValidateResponse']['Address']['Address1'])) ? trim($correctAddress['AddressValidateResponse']['Address']['Address1']) : '';
                    $patient->children('b', true)->PatientGeneralInfo->children('b', true)->DeliveryAddress->children('c', true)->City = trim($correctAddress['AddressValidateResponse']['Address']['City']);
                    $patient->children('b', true)->PatientGeneralInfo->children('b', true)->DeliveryAddress->children('c', true)->PostalCode = trim($correctAddress['AddressValidateResponse']['Address']['Zip5']);
                    $patient->children('b', true)->PatientGeneralInfo->children('b', true)->DeliveryAddress->children('c', true)->State = trim($correctAddress['AddressValidateResponse']['Address']['State']);

					//save old address in response
                    $new_delivery_address_obj = $patient->children('b', true)->PatientGeneralInfo->children('b', true)->DeliveryAddress->children('c', true);
                    $returnresponse['patients'][$BrightreeID]['new_addr']['AddressLine1'] = (string) $new_delivery_address_obj->AddressLine1;
					$returnresponse['patients'][$BrightreeID]['new_addr']['AddressLine2'] = (string) $new_delivery_address_obj->AddressLine2;
					$returnresponse['patients'][$BrightreeID]['new_addr']['City'] = (string) $new_delivery_address_obj->City;
					$returnresponse['patients'][$BrightreeID]['new_addr']['PostalCode'] = (string) $new_delivery_address_obj->PostalCode;
					$returnresponse['patients'][$BrightreeID]['new_addr']['State'] = (string) $new_delivery_address_obj->State;
					
                    //unset unwanted objects from xml
                    unset($patient->BrightreeID);
                    unset($patient->ExternalID);

                    $patientObjXML = str_replace(
                            array("<b:Patient>", "</b:Patient>"), array("<Patient>", "</Patient>"), $patient->asXML()
                    );

                    // Update patient object on brighttree			
                    $resultxml = simplexml_load_string((string) $this->obj->PatientUpdate($BrightreeID, $patientObjXML));
					
					$PatientUpdateResult=$resultxml->children('s', true)->children()->PatientUpdateResponse->children()->PatientUpdateResult->children('a', true);

                    //show result
                    if ((bool) $PatientUpdateResult->Success) {
                        $returnresponse['patients'][$BrightreeID]['address_update'] = true;
						$returnresponse['patients_updated'] ++ ;
                    } else {
                        $returnresponse['patients'][$BrightreeID]['address_update'] = false;
						$returnresponse['patients_not_updated'] ++ ;
						$returnresponse['patients'][$BrightreeID]['failure_message'] = $PatientUpdateResult->Messages;
                    }
                } else {
					$returnresponse['patients'][$BrightreeID]['address_verify'] = false;
					$returnresponse['patients_not_updated'] ++ ;
					$returnresponse['patients'][$BrightreeID]['failure_message'] = $verify->getErrorMessage();                    
                }
                $verify = NULL;
            }  
        }
		return $returnresponse;
    }
}