    <!--<div class="logo"><a href="#" title=""><img src="<?php echo base_url(); ?>theme/sos/images/sos-logo.png" alt="" /></a></div>
    <ul class="middleNav">
        <li class="iMes"><a href="#" title=""><span>Support tickets</span></a><span class="numberMiddle">9</span></li>

    </ul>-->
